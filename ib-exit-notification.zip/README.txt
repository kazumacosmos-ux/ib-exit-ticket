1-B出口 管理者プッシュ通知

このフォルダは通知機能だけをまとめたものです。

構成:
- notification.html
  管理者がiPadの通知を有効にするページ
- notification.js
  通知登録のメイン処理
- firebase-messaging-sw.js
  iPadのバックグラウンド通知を受け取るService Worker
- functions/index.js
  Firebase側で予約の新規作成・削除を検知して通知する処理
- functions/package.json
  Cloud Functionsの依存関係

重要:
1. Firebase Consoleで Cloud Messaging の Web Push 証明書から公開VAPIDキーを発行する。
2. notification.js の VAPID_KEY をその公開キーに置き換える。
3. Firebase Functions をデプロイする。
4. GitHub Pages のルートに notification.html / notification.js / firebase-messaging-sw.js を置く。
5. iPadで notification.html を開き、管理者ログイン→通知を有効化する。

現在の index.html は変更していません。

通知対象:
- Queue/reservations に新しい予約が作成されたとき
- Queue/reservations の予約が削除されたとき（キャンセル・管理者削除を含む）

注意:
- FirebaseのWeb PushはHTTPSが必要です。
- iPad側で通知許可が必要です。
- 実際の通知が届くかは、デプロイ後にテスト予約→キャンセルで確認してください。
