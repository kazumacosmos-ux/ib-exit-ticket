const { setGlobalOptions } = require("firebase-functions/v2");
const { onValueCreated, onValueDeleted } = require("firebase-functions/v2/database");
const { onRequest } = require("firebase-functions/v2/https");
const admin = require("firebase-admin");

admin.initializeApp();

setGlobalOptions({
  region: "asia-southeast1",
  maxInstances: 1
});

const db = admin.database();
const messaging = admin.messaging();

const ADMIN_EMAILS = new Set([
  "xkazuma.0906@gmail.com",
  "kazuma.cosmos@gmail.com"
]);

function cors(res) {
  res.set("Access-Control-Allow-Origin", "https://kazumacosmos-ux.github.io");
  res.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.set("Access-Control-Allow-Methods", "POST, OPTIONS");
}

exports.registerNotificationToken = onRequest(async (req, res) => {
  cors(res);

  if (req.method === "OPTIONS") {
    return res.status(204).send("");
  }

  if (req.method !== "POST") {
    return res.status(405).send("POST only");
  }

  try {
    const header = req.headers.authorization || "";
    if (!header.startsWith("Bearer ")) {
      return res.status(401).send("ログイン情報がありません。");
    }

    const idToken = header.substring("Bearer ".length);
    const decoded = await admin.auth().verifyIdToken(idToken);

    if (!ADMIN_EMAILS.has(decoded.email)) {
      return res.status(403).send("管理者ではありません。");
    }

    const token = String(req.body?.token || "").trim();

    if (!token || token.length < 20) {
      return res.status(400).send("通知トークンが不正です。");
    }

    await db.ref(`Queue/notificationTokens/${decoded.uid}/${encodeURIComponent(token)}`).set({
      token,
      email: decoded.email,
      updatedAt: Date.now()
    });

    return res.status(200).json({ ok: true });
  } catch (error) {
    console.error(error);
    return res.status(500).send("通知先の登録中にエラーが発生しました。");
  }
});

async function getTokens() {
  const snapshot = await db.ref("Queue/notificationTokens").once("value");
  const root = snapshot.val() || {};
  const tokens = [];

  for (const uid of Object.keys(root)) {
    for (const key of Object.keys(root[uid] || {})) {
      const item = root[uid][key];
      if (item?.token) tokens.push(item.token);
    }
  }

  return [...new Set(tokens)];
}

async function sendReservationNotification(title, body, reservation) {
  const tokens = await getTokens();

  if (!tokens.length) {
    console.log("通知先が登録されていません。");
    return;
  }

  const response = await messaging.sendEachForMulticast({
    tokens,
    notification: {
      title,
      body
    },
    webpush: {
      fcmOptions: {
        link: "https://kazumacosmos-ux.github.io/ib-exit-ticket/notification.html"
      }
    }
  });

  console.log(`通知送信: ${response.successCount}成功 / ${response.failureCount}失敗`);

  // 無効になったトークンを削除
  const updates = {};

  response.responses.forEach((result, index) => {
    if (!result.success) {
      const code = result.error?.code || "";
      if (
        code.includes("registration-token-not-registered") ||
        code.includes("invalid-registration-token")
      ) {
        updates[`Queue/notificationInvalidTokens/${encodeURIComponent(tokens[index])}`] = {
          removedAt: Date.now()
        };
      }
    }
  });

  if (Object.keys(updates).length) {
    await db.ref().update(updates);
  }
}

exports.notifyReservationCreated = onValueCreated(
  "/Queue/reservations/{reservationId}",
  async (event) => {
    const reservation = event.data.val();

    if (!reservation) return null;

    const start = reservation.start || "時間不明";
    const size = reservation.size || "?";
    const type =
      reservation.type === "paper" ? "紙予約" :
      reservation.type === "walkin" ? "当日受付" :
      "Web予約";

    await sendReservationNotification(
      "🟢 新しい予約が入りました",
      `${start}・${size}名・${type}`,
      reservation
    );

    return null;
  }
);

exports.notifyReservationDeleted = onValueDeleted(
  "/Queue/reservations/{reservationId}",
  async (event) => {
    const reservation = event.data.val();

    if (!reservation) return null;

    const start = reservation.start || "時間不明";
    const size = reservation.size || "?";

    await sendReservationNotification(
      "🔴 予約がキャンセルされました",
      `${start}・${size}名`,
      reservation
    );

    return null;
  }
);
